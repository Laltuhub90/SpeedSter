package com.speedster.app
// BootReceiver.kt content placeholder
